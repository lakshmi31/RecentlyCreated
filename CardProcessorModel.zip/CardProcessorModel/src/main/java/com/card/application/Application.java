package com.card.application;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.SpringCamelContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.card.router.Router;
/**
 * 
 * @author ldudhbha
 *
 */

@Configuration
@EnableAutoConfiguration
@ComponentScan
public class Application {

	// private static Main main;
	public static void main(String[] args) throws Exception {

		SpringApplication.run(Application.class, args);
	
	}
	 @Bean
	    public SpringCamelContext camelContext(ApplicationContext applicationContext) throws Exception {
	        SpringCamelContext camelContext = new SpringCamelContext(applicationContext);
	        camelContext.addRoutes(routeBuilder());
	        return camelContext;
	    }

	    @Bean
	    public RouteBuilder routeBuilder() {
	        return new Router();
	    }

}
