package com.card.constant;

/**
 * 
 * @author ldudhbha
 *
 */
public class Constants {

	public static String TIMER = "timer://event?fixedRate=true&period=30s";
	public static String SOURCE_URL_TO_CONSUME = "http://10.217.100.253:5223/consumer/getTopicMessage";
	public static String SOURCE_URL_TO_PRODUCE = "jms:queue:OUTPUT";
	public static String DESTINATION_URL_TCP = "mina2:tcp://localhost:6880?sync=false&textline=true";
	public static String DESTINATION_URL_JMS = "jms:queue:IN?jmsMessageType=Text";
	public static String DESTINATION_URL_TO_PRODUCE = "jms:queue:OUT?jmsMessageType=Text";
	public static String DESTINATION_NAME_TCP="TCP";
	public static String DESTINATION_NAME_JMS="jms";
	public static String DOZER_MAPPING_FILE = "mapping.xml";
	public static String ELEMENT_TAG_NAME = "Transaction";
	public static String ELEMENT_TAG_NAME_PROTOCOL = "protocol";
	public static String ELEMENT_TAG_NAME_PORT = "port";
	public static String ELEMENT_TAG_NAME_DESTINATIONIP = "destinationIP";
	public static String ELEMENT_TAG_NAME_SOURCE = "source";
	public static String SOURCE_DESTINATION_FILE = "source-destination.xml";

}
