package com.card.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.card.destination.model.CustomerResponseDest;
import com.card.dozer.DozerMapping;
import com.card.source.model.CustomerResponse;

public class MyProducerProcessor implements Processor {
	private static final Logger LOG = LoggerFactory.getLogger(MyProducerProcessor.class);
	/*
	 * @Autowired public DozerMapping dozerMapping;
	 */
	DozerMapping dozerMapping = new DozerMapping();
	
	public void process(Exchange exchange) throws Exception {
		LOG.info("In Processor:" + exchange.getIn().getBody());
		
		CustomerResponseDest customerDestinationResponse=(CustomerResponseDest) exchange.getIn().getBody();
		
		CustomerResponse customerResponse=dozerMapping.mappedObject(customerDestinationResponse);
		
		exchange.getOut().setBody(customerResponse);
	}
}
