package com.card.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.card.destination.model.CustomerDestination;
import com.card.dozer.DozerMapping;
import com.card.source.model.Customer;

/**
 * 
 * @author ldudhbha
 *
 */
@Component
public class MyConsumerProcessor implements Processor {

	private static final Logger LOG = LoggerFactory.getLogger(MyConsumerProcessor.class);
	
	DozerMapping dozerMapping = new DozerMapping();

	public void process(Exchange exchange) throws Exception {
		LOG.info("Inside Processor:" + exchange.getIn().getBody());
		Customer customerSource = (Customer) exchange.getIn().getBody();

		CustomerDestination customerDestination = dozerMapping.mappedObject(customerSource);
		LOG.info("Sending exchange is:" + customerDestination.toString());
		exchange.getOut().setBody(customerDestination.toString());
	}

}
