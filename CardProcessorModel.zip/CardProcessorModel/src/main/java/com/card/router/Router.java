package com.card.router;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.RouteDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.card.common.ReadSourceDestinationXML;
import com.card.common.SourceDestination;
import com.card.constant.Constants;
import com.card.destination.model.CustomerResponseDest;
import com.card.processor.MyConsumerProcessor;
import com.card.processor.MyProducerProcessor;
import com.card.source.model.Customer;

/**
 * Consumer router to route message from ProcessorModel to Simulator
 *
 */
@Component
public class Router extends RouteBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(Router.class);
	ReadSourceDestinationXML readSourceDestinationXML = new ReadSourceDestinationXML();

	@Override
	public void configure() throws Exception {
		SourceDestination sourceDestination = readSourceDestinationXML.readXML();
		LOG.info("protocol is:" + sourceDestination.getProtocol());
		((RouteDefinition) from(Constants.TIMER).to(Constants.SOURCE_URL_TO_CONSUME).unmarshal().json(JsonLibrary.Jackson, Customer.class)
				.process(new MyConsumerProcessor())
				.setHeader(sourceDestination.getProtocol(), constant(sourceDestination.getProtocol())).choice()
				.when(header(sourceDestination.getProtocol()).isEqualTo(Constants.DESTINATION_NAME_JMS))
				.to(sourceDestination.getProtocol() + ":" + sourceDestination.getPort() + ":"
						+ sourceDestination.getDestinationIP() + "?jmsMessageType=Text")
				.when(header(sourceDestination.getProtocol()).isEqualTo(Constants.DESTINATION_NAME_TCP))
				.to(Constants.DESTINATION_URL_TCP).end()).from(Constants.DESTINATION_URL_TO_PRODUCE).marshal().json(JsonLibrary.Jackson, CustomerResponseDest.class)
				.process(new MyProducerProcessor()).log("Response body:${body}")
				.to(Constants.SOURCE_URL_TO_PRODUCE);
	}

}
